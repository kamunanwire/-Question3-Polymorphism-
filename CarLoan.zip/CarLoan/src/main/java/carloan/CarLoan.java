package carloan;
abstract class Loan {
    private String loanID;
    private String loanType;
    private int amountUGX;
    private String custName;
    public Loan()
    {
          this.amountUGX = 0;
    }
    public void setLoanId(String loanID)
    {
        this.loanID = loanID;
    }
    public String getLoanId()
    {
        return loanID;
    }
    public void setCustomerName(String custName) 
    {
        this.custName = custName;
    }
    public String getCustomerName()
    {
        return custName;
    }
    public void setAmount(int amountUGX)
    {
        this.amountUGX = amountUGX;
    }
    public int getAmount() 
    {
        return amountUGX;
    }
    public String getFormattedAmount()
    {
        return String.format("UGX %,d", amountUGX);
    }
    public abstract String getLoanType();
}
public class CarLoan extends Loan
{
    private String carLien;
    public CarLoan() 
    {
        super();
    }
    public void setCarLien(String carLien)
    {
        this.carLien = carLien;
    }
    public String getCarLien()
    {
        return carLien;
    }
    @Override
    public String getLoanType()
    {
        return "Car Loan";
    }

}
