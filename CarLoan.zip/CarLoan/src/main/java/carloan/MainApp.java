package carloan;

public class MainApp {
    public static void main(String[] args) {
        // Create a CarLoan object
        CarLoan carLoan = new CarLoan();
      
        // Set the properties for the CarLoan object
        carLoan.setLoanId("KE324");
        carLoan.setCustomerName("Kamel Soft");
        carLoan.setAmount(25000000);  // Amount in UGX
        carLoan.setCarLien("2000");   // Car lien as a string

        // Print details of the CarLoan object
        System.out.println("Car Loan Details:");
        System.out.println("Loan ID: " + carLoan.getLoanId());
        System.out.println("Customer Name: " + carLoan.getCustomerName());
        System.out.println("Loan Amount: " + carLoan.getFormattedAmount());
        System.out.println("Car Lien: " + carLoan.getCarLien());
        System.out.println("Loan Type: " + carLoan.getLoanType());
    }
}
